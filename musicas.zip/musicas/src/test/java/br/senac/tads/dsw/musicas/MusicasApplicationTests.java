package br.senac.tads.dsw.musicas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicasApplicationTests {

	@Test
	void contextLoads() {
	}

}
